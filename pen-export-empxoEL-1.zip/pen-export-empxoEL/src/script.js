// 应用状态

let currentDeckId = null;

let currentCardIndex = 0;

// DOM 元素

const views = {

    home: document.getElementById('home-view'),

    deck: document.getElementById('deck-view'),

    study: document.getElementById('study-view')

};

// 初始化

document.addEventListener('DOMContentLoaded', initApp);

function initApp() {

    loadDecks();

    setupEventListeners();

}

function setupEventListeners() {

    // 主页事件

    document.getElementById('create-deck-btn').addEventListener('click', showAddDeckModal);

    document.getElementById('add-deck-form').addEventListener('submit', handleAddDeck);

    document.getElementById('cancel-add-deck').addEventListener('click', hideAddDeckModal);

    // 详情页事件

    document.getElementById('back-to-home').addEventListener('click', showHomeView);

    document.getElementById('study-deck-btn').addEventListener('click', startStudying);

    document.getElementById('add-card-btn').addEventListener('click', showAddCardModal);

    document.getElementById('add-card-form').addEventListener('submit', handleAddCard);

    document.getElementById('cancel-add-card').addEventListener('click', hideAddCardModal);

    // 学习页事件

    document.getElementById('exit-study').addEventListener('click', exitStudy);

    document.getElementById('flip-card').addEventListener('click', flipCard);

    document.getElementById('study-card').addEventListener('click', flipCard);

    document.getElementById('mark-known').addEventListener('click', markAsKnown);

    document.getElementById('next-card').addEventListener('click', showNextCard);

}

// 数据操作函数

function getDecks() {

    const decks = localStorage.getItem('smartStudyDecks');

    return decks ? JSON.parse(decks) : {};

}

function saveDecks(decks) {

    localStorage.setItem('smartStudyDecks', JSON.stringify(decks));

}

function loadDecks() {

    const decks = getDecks();

    const decksList = document.getElementById('decks-list');

    decksList.innerHTML = '';

    if (Object.keys(decks).length === 0) {

        decksList.innerHTML = '<p style="color: white; margin-top: 2rem;">还没有卡片组，点击上方按钮创建一个吧！</p>';

        return;

    }

    for (const deckId in decks) {

        const deck = decks[deckId];

        const li = document.createElement('li');

        li.innerHTML = `

            <span>${deck.name}</span>

            <small>${deck.cards.length} 张卡片</small>

        `;

        li.addEventListener('click', () => showDeckView(deckId));

        decksList.appendChild(li);

    }

}

// 视图切换函数

function showView(viewName) {

    for (const key in views) {

        views[key].classList.add('hidden');

    }

    views[viewName].classList.remove('hidden');

}

function showHomeView() {

    loadDecks();

    showView('home');

}

function showDeckView(deckId) {

    currentDeckId = deckId;

    const decks = getDecks();

    const deck = decks[deckId];

    document.getElementById('deck-title').textContent = deck.name;

    const cardsList = document.getElementById('cards-list');

    cardsList.innerHTML = '';

    if (deck.cards.length === 0) {

        cardsList.innerHTML = '<p style="text-align: center; color: #666; margin-top: 2rem;">这个卡片组是空的，添加一些卡片吧！</p>';

    } else {

        deck.cards.forEach(card => {

            const li = document.createElement('li');

            li.innerHTML = `

                <div>

                    <strong>${card.front}</strong>

                    <br>

                    <small>${card.back}</small>

                </div>

                <span style="color: ${card.known ? '#4CAF50' : '#FF6B6B'}; font-size: 0.8em;">

                    ${card.known ? '已掌握' : '待学习'}

                </span>

            `;

            cardsList.appendChild(li);

        });

    }

    showView('deck');

}

// 弹窗控制

function showAddDeckModal() {

    document.getElementById('add-deck-modal').classList.remove('hidden');

}

function hideAddDeckModal() {

    document.getElementById('add-deck-modal').classList.add('hidden');

    document.getElementById('add-deck-form').reset();

}

function showAddCardModal() {

    document.getElementById('add-card-modal').classList.remove('hidden');

}

function hideAddCardModal() {

    document.getElementById('add-card-modal').classList.add('hidden');

    document.getElementById('add-card-form').reset();

}

// 表单处理

function handleAddDeck(e) {

    e.preventDefault();

    const deckName = document.getElementById('deck-name-input').value.trim();

    

    if (deckName) {

        const decks = getDecks();

        const deckId = 'deck' + Date.now();

        

        decks[deckId] = {

            id: deckId,

            name: deckName,

            cards: []

        };

        

        saveDecks(decks);

        hideAddDeckModal();

        loadDecks();

    }

}

function handleAddCard(e) {

    e.preventDefault();

    const front = document.getElementById('card-front-input').value.trim();

    const back = document.getElementById('card-back-input').value.trim();

    

    if (front && back) {

        const decks = getDecks();

        const cardId = 'card' + Date.now();

        

        decks[currentDeckId].cards.push({

            id: cardId,

            front: front,

            back: back,

            known: false

        });

        

        saveDecks(decks);

        hideAddCardModal();

        showDeckView(currentDeckId);

    }

}

// 学习功能

function startStudying() {

    const decks = getDecks();

    const deck = decks[currentDeckId];

    

    if (deck.cards.length === 0) {

        alert('这个卡片组还没有卡片，请先添加一些卡片再学习！');

        return;

    }

    

    currentCardIndex = 0;

    showView('study');

    showCurrentCard();

}

function showCurrentCard() {

    const decks = getDecks();

    const deck = decks[currentDeckId];

    const card = deck.cards[currentCardIndex];

    

    document.getElementById('card-front-text').textContent = card.front;

    document.getElementById('card-back-text').textContent = card.back;

    document.getElementById('progress').textContent = `${currentCardIndex + 1} / ${deck.cards.length}`;

    

    // 重置卡片翻转状态

    document.getElementById('study-card').classList.remove('flipped');

    document.querySelector('.card-back').classList.add('hidden');

    document.querySelector('.card-front').classList.remove('hidden');

}

function flipCard() {

    const card = document.getElementById('study-card');

    card.classList.toggle('flipped');

}

function markAsKnown() {

    const decks = getDecks();

    decks[currentDeckId].cards[currentCardIndex].known = true;

    saveDecks(decks);

    showNextCard();

}

function showNextCard() {

    const decks = getDecks();

    const deck = decks[currentDeckId];

    

    currentCardIndex++;

    if (currentCardIndex >= deck.cards.length) {

        if (confirm('恭喜！你已经学完了所有卡片。是否重新开始？')) {

            currentCardIndex = 0;

        } else {

            exitStudy();

            return;

        }

    }

    showCurrentCard();

}

function exitStudy() {

    showDeckView(currentDeckId);

}